# Custom > 2024-04-02 11:21am
https://universe.roboflow.com/custom-detection-vdywz/custom-v3kvp

Provided by a Roboflow user
License: CC BY 4.0

