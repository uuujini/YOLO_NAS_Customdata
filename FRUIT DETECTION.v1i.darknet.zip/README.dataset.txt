# FRUIT DETECTION > 2023-03-12 2:42pm
https://universe.roboflow.com/fruit-detection-w707e/fruit-detection-deqvb

Provided by a Roboflow user
License: CC BY 4.0

